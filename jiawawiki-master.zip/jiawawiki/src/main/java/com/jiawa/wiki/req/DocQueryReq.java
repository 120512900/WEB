package com.jiawa.wiki.req;

public class DocQueryReq extends PageReq {
    @Override
    public String toString() {
        return "DocQueryReq{} " + super.toString();
    }
}
