package com.jiawa.wiki.mapper;

import com.jiawa.wiki.domain.Test;

import java.util.List;

public interface TestMapper {

    public List<Test> list();
}
