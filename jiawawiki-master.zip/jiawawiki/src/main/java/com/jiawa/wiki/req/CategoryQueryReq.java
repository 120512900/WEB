package com.jiawa.wiki.req;

public class CategoryQueryReq extends PageReq {
    @Override
    public String toString() {
        return "CategoryQueryReq{} " + super.toString();
    }
}
