<template>
  <a-layout>
    <a-layout-content :style="{ background: '#fff', padding: '24px', margin: 0, minHeight: '280px' }">
      <div class="aliyun">
        <h2>阿里云购买指导优惠</h2>
        <div><b>如果你还没用过云服务，那就落伍了！</b></div>
        <div><b>每个程序员都应该有一个自己的线上作品</b></div>
        <div><b>可以是博客、在线笔记，WIKI知识库等，用于技术积累，面试加分</b></div>
        <br>
        <div style="color: rgb(249, 150, 59)"><b>阿里云选购指导、优惠、代金券，可联系QQ：82144921</b></div>
        <div style="color: rgb(249, 150, 59)"><b>自助优惠：
          <a href="https://partner.aliyun.com/shop/1704506477397431" target="_blank">https://partner.aliyun.com/shop/1704506477397431</a></b>
        </div>
        <br>
        <div style="color: rgb(194, 79, 74)"><b>还没注册过阿里云的可以先QQ联系，灰常便宜！！！</b></div>
        <div>
          <img src="http://www.jiawablog.com/image/aliyun1.jpg">
        </div>
      </div>
    </a-layout-content>
  </a-layout>
</template>

<style>
  .aliyun {
    line-height: 30px;
    padding: 40px;
    background-color: #f5f5f5;
    font-size: 16px;
  }
  .aliyun h2 {
    margin-bottom: 30px;
    font-weight: 700;
  }
  .aliyun img {
    margin-top: 10px;
  }
</style>
