<template>
  <a-layout>
    <a-layout-content :style="{ background: '#fff', padding: '24px', margin: 0, minHeight: '280px' }">
      <div class="about">
        <h2>我是甲蛙，13年Java全栈，慕课网讲师</h2>
        <div><b>专注Java全栈技术分享，汇总13年实战经验</b></div>
        <div>
          <b>项目实战：
            <a href="https://coding.imooc.com/class/474.html" target="_blank">
            《SpringBoot知识体系+Vue3全家桶 前后端分离 实战WIKI知识库系统》
            </a>
          </b>
        </div>
        <div>
          <b>项目实战：
            <a href="https://coding.imooc.com/class/416.html" target="_blank">
            《Spring Cloud + Vue 前后端分离 开发企业级在线视频课程系统》
            </a>
          </b>
        </div>
        <div>
          <b>免费课程：
            <a href="https://www.imooc.com/learn/1160" target="_blank">
            《开发工具IDEA从入门到爱不释手》
            </a>
          </b>
        </div>
        <br>
        <div><b>QQ：82144921，<span style="color: rgb(194, 79, 74)">阿里云产品使用咨询、购买优惠</span>，加QQ，备注：阿里云</b></div>
        <div><b>微信号：jiawa1986</b></div>
        <div><b>QQ群：174545069，Java全栈交流群</b></div>
        <div><b>个人全栈技术博客：
          <a href="http://www.jiawablog.com" target="_blank">甲蛙博客</a></b>
        </div>
        <div style="color: rgb(194, 79, 74)"><b>公众号：甲蛙全栈，扫码关注</b></div>
        <div>
          <img src="/image/jiawaquanzhan.jpg">
        </div>
      </div>
    </a-layout-content>
  </a-layout>
</template>

<style>
  .about {
    line-height: 30px;
    padding: 40px;
    background-color: #f5f5f5;
    font-size: 16px;
  }
  .about h2 {
    margin-bottom: 30px;
    font-weight: 700;
  }
  .about img {
    margin-top: 10px;
  }
</style>
